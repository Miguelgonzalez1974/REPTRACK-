// Datos y configuración global
let entries = JSON.parse(localStorage.getItem('rtCrossData_vFinal') || '[]');
let editId = null;
let selRPE = null;
let chartInstances = {};
let currentFilterMovement = null;
let currentPage = 1;
const itemsPerPage = 5;

// Lista de movimientos WOD con categorías
const WOD_MOVEMENTS = [
    // Gimnásticos
    { name: 'Pull-up', category: 'Gymnastics' },
    { name: 'Push-up', category: 'Gymnastics' },
    { name: 'Handstand Push-up', category: 'Gymnastics' },
    { name: 'Muscle-up', category: 'Gymnastics' },
    { name: 'Toes-to-bar', category: 'Gymnastics' },
    { name: 'Bar Muscle-up', category: 'Gymnastics' },
    { name: 'Ring Muscle-up', category: 'Gymnastics' },
    { name: 'Dip', category: 'Gymnastics' },
    { name: 'Handstand Walk', category: 'Gymnastics' },
    { name: 'Pistol', category: 'Gymnastics' },
    { name: 'Rope Climb', category: 'Gymnastics' },
    
    // Halterofilia
    { name: 'Clean', category: 'Weightlifting' },
    { name: 'Snatch', category: 'Weightlifting' },
    { name: 'Jerk', category: 'Weightlifting' },
    { name: 'Thruster', category: 'Weightlifting' },
    { name: 'Deadlift', category: 'Weightlifting' },
    { name: 'Bench Press', category: 'Weightlifting' },
    { name: 'Squat', category: 'Weightlifting' },
    { name: 'Shoulder Press', category: 'Weightlifting' },
    { name: 'Push Press', category: 'Weightlifting' },
    { name: 'Overhead Squat', category: 'Weightlifting' },
    { name: 'Front Squat', category: 'Weightlifting' },
    { name: 'Sumo Deadlift High Pull', category: 'Weightlifting' },
    
    // Cardio
    { name: 'Run', category: 'Cardio' },
    { name: 'Row', category: 'Cardio' },
    { name: 'Bike', category: 'Cardio' },
    { name: 'Ski Erg', category: 'Cardio' },
    { name: 'Double Under', category: 'Cardio' },
    { name: 'Single Under', category: 'Cardio' },
    
    // Bodyweight
    { name: 'Burpee', category: 'Bodyweight' },
    { name: 'Wall Ball', category: 'Bodyweight' },
    { name: 'Air Squat', category: 'Bodyweight' },
    { name: 'Lunge', category: 'Bodyweight' },
    { name: 'Sit-up', category: 'Bodyweight' },
    { name: 'GHD Sit-up', category: 'Bodyweight' },
    { name: 'Back Extension', category: 'Bodyweight' },
    { name: 'Kettlebell Swing', category: 'Bodyweight' },
    { name: 'Box Jump', category: 'Bodyweight' }
];

// --- FUNCIONES DE NAVEGACIÓN ---
document.querySelectorAll('.tab-btn').forEach(btn => {
    btn.onclick = () => {
        document.querySelectorAll('section').forEach(s => s.classList.add('hidden'));
        document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
        btn.classList.add('active');
        document.getElementById('dash' + btn.id.slice(3)).classList.remove('hidden');

        // Cargar datos específicos para cada pestaña
        switch(btn.id) {
            case 'tabHistoric': renderHistoric(); break;
            case 'tabProgress': renderProgress(); break;
            case 'tabStats': renderStats(); break;
            case 'tabRM': renderRM(); break;
            case 'tabWODMov': renderWODAnalysis(); break;
        }
    };
});

// --- MODO OSCURO ---
function toggleDarkMode() {
    document.documentElement.classList.toggle('dark');
    localStorage.setItem('darkMode', document.documentElement.classList.contains('dark'));
    updateDarkModeIcon();
    updateChartThemes();
}

function updateDarkModeIcon() {
    const icon = document.getElementById('darkModeIcon');
    if (document.documentElement.classList.contains('dark')) {
        icon.classList.replace('fa-moon', 'fa-sun');
    } else {
        icon.classList.replace('fa-sun', 'fa-moon');
    }
}

function updateChartThemes() {
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#e5e7eb' : '#374151';
    const gridColor = isDark ? 'rgba(229, 231, 235, 0.1)' : 'rgba(55, 65, 81, 0.1)';
    
    Object.values(chartInstances).forEach(chart => {
        if (chart) {
            chart.options.scales.x.grid.color = gridColor;
            chart.options.scales.y.grid.color = gridColor;
            chart.options.scales.x.ticks.color = textColor;
            chart.options.scales.y.ticks.color = textColor;
            if (chart.options.plugins?.legend?.labels) {
                chart.options.plugins.legend.labels.color = textColor;
            }
            chart.update();
        }
    });
}

document.getElementById('darkModeToggle').addEventListener('click', toggleDarkMode);

// Verificar preferencia de modo oscuro al cargar
if (localStorage.getItem('darkMode') === 'true' || 
    (window.matchMedia('(prefers-color-scheme: dark)').matches && !localStorage.getItem('darkMode'))) {
    document.documentElement.classList.add('dark');
}
updateDarkModeIcon();

// --- FUNCIONES DE REGISTRO ---
const condTypeEl = document.getElementById('condType');
function loadCondTypes() {
    const types = JSON.parse(localStorage.getItem('condTypes_vFinal') || '["AMRAP", "For Time", "EMOM", "RFT", "Chipper"]');
    condTypeEl.innerHTML = types.map(t => `<option>${t}</option>`).join('');
}
document.getElementById('addCondType').onclick = () => {
    const n = prompt('Nuevo tipo de WOD:');
    if (n) {
        const types = JSON.parse(localStorage.getItem('condTypes_vFinal') || '["AMRAP", "For Time", "EMOM"]');
        types.push(n);
        localStorage.setItem('condTypes_vFinal', JSON.stringify(types));
        loadCondTypes();
    }
};

// Configurar RPE con iconos más descriptivos
document.querySelectorAll('#rpeIcons i').forEach(i => i.onclick = () => {
    selRPE = i.dataset.val;
    document.querySelectorAll('#rpeIcons i').forEach(x => {
        x.classList.remove('text-green-400', 'text-blue-400', 'text-yellow-400', 'text-orange-400', 'text-red-400', 'active');
        
        if (parseInt(x.dataset.val) <= parseInt(selRPE)) {
            switch(x.dataset.val) {
                case '1': x.classList.add('text-green-400'); break;
                case '2': x.classList.add('text-blue-400'); break;
                case '3': x.classList.add('text-yellow-400'); break;
                case '4': x.classList.add('text-orange-400'); break;
                case '5': x.classList.add('text-red-400'); break;
            }
            x.classList.add('active');
        }
    });
});

// Funcionalidad de Weightlifting
const liftContainer = document.getElementById('liftContainer');
let liftBlockCounter = 0;

function createLiftBlock(data = null) {
    liftBlockCounter++;
    const blockId = `lift-block-${liftBlockCounter}`;
    const div = document.createElement('div');
    div.id = blockId;
    div.className = 'border bg-white dark:bg-gray-700 p-4 rounded-lg mb-4 relative shadow-sm';
    div.innerHTML = `
        <button class="remove-lift-btn absolute -top-2 -right-2 bg-red-500 text-white rounded-full h-6 w-6 flex items-center justify-center text-xs font-bold hover:bg-red-600 transition">&times;</button>
        <div class="flex gap-2 mb-2">
            <select class="lift-move border p-2 rounded flex-1 dark:bg-gray-600 dark:border-gray-500 dark:text-white"></select>
            <button class="add-move-btn bg-green-600 dark:bg-green-700 text-white px-2 rounded hover:bg-green-700 dark:hover:bg-green-800 transition"><i class="fas fa-plus"></i></button>
        </div>
        <div>
            <label class="font-semibold text-sm dark:text-gray-300">Nº de Rondas:</label>
            <input type="number" min="1" class="rounds-input border p-2 rounded w-full dark:bg-gray-600 dark:border-gray-500 dark:text-white"/>
        </div>
        <div class="rounds-container mt-3 space-y-3"></div>
    `;
    liftContainer.appendChild(div);

    const moveSelect = div.querySelector('.lift-move');
    const moveTypes = JSON.parse(localStorage.getItem('liftTypes_vFinal') || '["Clean","Snatch","Jerk","Thruster","OHS","Deadlift","Bench Press","Squat","Shoulder Press","Push Press"]');
    moveSelect.innerHTML = moveTypes.map(m => `<option>${m}</option>`).join('');

    div.querySelector('.add-move-btn').onclick = () => {
        const n = prompt('Nuevo movimiento:');
        if (n) {
            moveTypes.push(n);
            localStorage.setItem('liftTypes_vFinal', JSON.stringify(moveTypes));
            moveSelect.innerHTML = moveTypes.map(m => `<option>${m}</option>`).join('');
            moveSelect.value = n;
        }
    };
    
    div.querySelector('.remove-lift-btn').onclick = () => div.remove();
    
    const roundsInput = div.querySelector('.rounds-input');
    const roundsContainer = div.querySelector('.rounds-container');

    roundsInput.oninput = () => {
        roundsContainer.innerHTML = '';
        const numRounds = parseInt(roundsInput.value) || 0;
        for (let i = 1; i <= numRounds; i++) {
            const roundDiv = document.createElement('div');
            roundDiv.className = 'p-3 border rounded-md bg-gray-50 dark:bg-gray-600 lift-round';
            roundDiv.innerHTML = `
                <strong class="text-gray-700 dark:text-gray-300 text-sm">Ronda ${i}</strong>
                <div class="grid grid-cols-2 gap-4 mt-1">
                    <div>
                        <label class="text-xs dark:text-gray-400">Nº Reps</label>
                        <input type="number" class="round-reps-input w-full border p-1 rounded dark:bg-gray-500 dark:border-gray-400 dark:text-white" placeholder="Reps">
                    </div>
                    <div>
                        <label class="text-xs dark:text-gray-400">Pesos (kg)</label>
                        <input type="text" class="round-weights-input w-full border p-1 rounded dark:bg-gray-500 dark:border-gray-400 dark:text-white" placeholder="60, 65, 70">
                    </div>
                </div>
            `;
            roundsContainer.appendChild(roundDiv);
        }
    };

    if (data) {
        moveSelect.value = data.move;
        roundsInput.value = data.roundsData.length;
        roundsInput.dispatchEvent(new Event('input')); 

        const roundDivs = div.querySelectorAll('.rounds-container > div');
        data.roundsData.forEach((round, index) => {
            if (roundDivs[index]) {
                roundDivs[index].querySelector('.round-reps-input').value = round.reps;
                roundDivs[index].querySelector('.round-weights-input').value = round.weights.join(', ');
            }
        });
    }
}

document.getElementById('addLift').onclick = () => createLiftBlock();

// Guardar sesión
document.getElementById('saveBtn').onclick = () => {
    const cond = {
        date: document.getElementById('condDate').value || new Date().toISOString().split('T')[0], 
        type: condTypeEl.value,
        wodText: document.getElementById('condWOD').value, 
        result: document.getElementById('condResult').value, 
        rpe: selRPE
    };

    const wl = [];
    liftContainer.querySelectorAll('.border.bg-white, .border.dark\\:bg-gray-700').forEach(block => {
        const rounds = block.querySelectorAll('.rounds-container > div');
        if (rounds.length > 0) {
            const roundsData = [...rounds].map(r => ({
                reps: parseInt(r.querySelector('.round-reps-input').value) || 0,
                weights: r.querySelector('.round-weights-input').value.split(',').map(s => parseFloat(s.trim())).filter(n => !isNaN(n))
            }));
            wl.push({ 
                move: block.querySelector('.lift-move').value, 
                roundsData: roundsData 
            });
        }
    });

    if (editId) {
        const index = entries.findIndex(e => e.id === editId);
        entries[index] = { id: editId, cond, wl };
        showAlert('✅ Sesión Actualizada', 'green');
    } else {
        entries.push({ id: Date.now(), cond, wl });
        showAlert('✅ Sesión Guardada', 'green');
    }

    localStorage.setItem('rtCrossData_vFinal', JSON.stringify(entries));
    resetForm();
    document.getElementById('tabHistoric').click();
};

// Cancelar edición
document.getElementById('cancelBtn').onclick = () => { 
    if (confirm("¿Descartar cambios?")) resetForm(); 
};

function resetForm() {
    editId = null;
    selRPE = null;
    document.getElementById('condDate').valueAsDate = new Date();
    condTypeEl.selectedIndex = 0;
    document.getElementById('condWOD').value = '';
    document.getElementById('condResult').value = '';
    document.querySelectorAll('#rpeIcons i').forEach(i => {
        i.classList.remove('text-green-400', 'text-blue-400', 'text-yellow-400', 'text-orange-400', 'text-red-400', 'active');
    });
    liftContainer.innerHTML = '';
    document.getElementById('formTitle').innerHTML = '<i class="fas fa-edit mr-3 text-indigo-600 dark:text-indigo-400"></i>Registrar Sesión';
    document.getElementById('saveBtn').innerHTML = '<i class="fas fa-save"></i>Guardar Sesión';
    document.getElementById('cancelBtn').classList.add('hidden');
}

function showAlert(message, color = 'blue') {
    const alert = document.createElement('div');
    alert.className = `fixed top-4 right-4 bg-${color}-500 text-white px-4 py-2 rounded-lg shadow-lg flex items-center gap-2 z-50`;
    alert.innerHTML = `${message} <button class="ml-2" onclick="this.parentElement.remove()"><i class="fas fa-times"></i></button>`;
    document.body.appendChild(alert);
    setTimeout(() => alert.remove(), 3000);
}

// --- FUNCIONES DE HISTÓRICO ---
function renderHistoric() {
    const c = document.getElementById('historicContainer');
    c.innerHTML = '';
    
    if (entries.length === 0) {
        c.innerHTML = '<div class="text-center py-8 text-gray-500 dark:text-gray-400">No hay sesiones registradas aún</div>';
        return;
    }
    
    entries.sort((a, b) => new Date(b.cond.date) - new Date(a.cond.date)).forEach(e => {
        const div = document.createElement('div');
        div.className = 'bg-white dark:bg-gray-700 rounded-lg p-4 shadow-md border dark:border-gray-600';
        const wlHtml = e.wl.map(w => `
            <div class="mt-2 bg-green-50 dark:bg-green-900 p-3 rounded-md border border-green-200 dark:border-green-700">
                <p class="font-bold text-green-800 dark:text-green-300">${w.move}</p>
                <ul class="list-disc ml-5 text-sm text-gray-700 dark:text-gray-300">
                    ${w.roundsData.map((r, i) => `<li><strong>Ronda ${i + 1}:</strong> ${r.reps} reps con [${r.weights.join(', ')}] kg</li>`).join('')}
                </ul>
            </div>
        `).join('');

        div.innerHTML = `
            <div class="flex justify-between items-start">
                <div>
                    <strong class="text-indigo-700 dark:text-indigo-300 text-lg">${formatDate(e.cond.date)}</strong>
                    <p class="text-sm text-gray-600 dark:text-gray-400">${e.cond.type || 'N/A'} ${e.cond.rpe ? `- RPE: ${e.cond.rpe}` : ''}</p>
                </div>
                <div class="flex gap-2 flex-shrink-0">
                    <button class="edit-btn bg-blue-500 text-white w-10 h-10 rounded-full hover:bg-blue-600 flex items-center justify-center transition" data-id="${e.id}"><i class="fas fa-edit"></i></button>
                    <button class="delete-btn bg-red-500 text-white w-10 h-10 rounded-full hover:bg-red-600 flex items-center justify-center transition" data-id="${e.id}"><i class="fas fa-trash"></i></button>
                </div>
            </div>
            ${e.cond.wodText ? `<div class="mt-3 bg-indigo-50 dark:bg-indigo-900 p-3 rounded-md border border-indigo-200 dark:border-indigo-700">
                <p class="font-semibold text-indigo-800 dark:text-indigo-300">WOD:</p>
                <p class="text-gray-700 dark:text-gray-300 whitespace-pre-line">${e.cond.wodText}</p>
                ${e.cond.result ? `<p class="mt-2 dark:text-gray-300"><strong>Resultado:</strong> ${e.cond.result}</p>` : ''}
            </div>` : ''}
            ${wlHtml}
        `;

        c.appendChild(div);
    });

    // Eventos para botones de edición/eliminación
    document.querySelectorAll('.edit-btn').forEach(btn => {
        btn.onclick = () => {
            const id = parseInt(btn.dataset.id);
            const entry = entries.find(e => e.id === id);
            if (entry) {
                editId = id;
                document.getElementById('condDate').value = entry.cond.date;
                condTypeEl.value = entry.cond.type;
                document.getElementById('condWOD').value = entry.cond.wodText || '';
                document.getElementById('condResult').value = entry.cond.result || '';
                
                if (entry.cond.rpe) {
                    selRPE = entry.cond.rpe;
                    document.querySelectorAll('#rpeIcons i').forEach(x => {
                        x.classList.remove('text-green-400', 'text-blue-400', 'text-yellow-400', 'text-orange-400', 'text-red-400', 'active');
                        if (parseInt(x.dataset.val) <= parseInt(selRPE)) {
                            switch(x.dataset.val) {
                                case '1': x.classList.add('text-green-400'); break;
                                case '2': x.classList.add('text-blue-400'); break;
                                case '3': x.classList.add('text-yellow-400'); break;
                                case '4': x.classList.add('text-orange-400'); break;
                                case '5': x.classList.add('text-red-400'); break;
                            }
                            x.classList.add('active');
                        }
                    });
                }
                
                liftContainer.innerHTML = '';
                entry.wl.forEach(w => createLiftBlock(w));
                
                document.getElementById('formTitle').innerHTML = '<i class="fas fa-edit mr-3 text-indigo-600 dark:text-indigo-400"></i>Editando Sesión';
                document.getElementById('saveBtn').innerHTML = '<i class="fas fa-save"></i>Actualizar Sesión';
                document.getElementById('cancelBtn').classList.remove('hidden');
                document.getElementById('tabInput').click();
            }
        };
    });

    document.querySelectorAll('.delete-btn').forEach(btn => {
        btn.onclick = () => {
            if (confirm('¿Eliminar esta sesión?')) {
                const id = parseInt(btn.dataset.id);
                entries = entries.filter(e => e.id !== id);
                localStorage.setItem('rtCrossData_vFinal', JSON.stringify(entries));
                renderHistoric();
                showAlert('🗑️ Sesión eliminada', 'red');
            }
        };
    });
}

function formatDate(dateStr) {
    const date = new Date(dateStr);
    return date.toLocaleDateString('es-ES', { weekday: 'short', day: 'numeric', month: 'short' });
}

// --- FUNCIONES DE PROGRESO ---
function renderProgress() {
    // Datos para gráfico de RPE
    const rpeData = entries.filter(e => e.cond.rpe).sort((a, b) => new Date(a.cond.date) - new Date(b.cond.date));
    const rpeLabels = rpeData.map(e => formatDate(e.cond.date));
    const rpeValues = rpeData.map(e => e.cond.rpe);
    
    // Datos para movimientos más frecuentes
    const moveCounts = {};
    entries.forEach(e => {
        e.wl.forEach(w => {
            moveCounts[w.move] = (moveCounts[w.move] || 0) + 1;
        });
    });
    const sortedMoves = Object.entries(moveCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);
    
    // Datos para volumen semanal
    const weeklyVol = {};
    entries.forEach(e => {
        const date = new Date(e.cond.date);
        const week = `${date.getFullYear()}-W${String(date.getWeek()).padStart(2, '0')}`;
        let vol = 0;
        e.wl.forEach(w => {
            w.roundsData.forEach(r => {
                vol += r.reps * r.weights.reduce((a, b) => a + b, 0) / r.weights.length;
            });
        });
        weeklyVol[week] = (weeklyVol[week] || 0) + vol;
    });
    const sortedWeeks = Object.entries(weeklyVol).sort((a, b) => a[0].localeCompare(b[0]));
    
    // Configuración del tema para gráficos
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#e5e7eb' : '#374151';
    const gridColor = isDark ? 'rgba(229, 231, 235, 0.1)' : 'rgba(55, 65, 81, 0.1)';
    
    // Renderizar gráficos
    renderChart('chartRPE', {
        type: 'line',
        data: {
            labels: rpeLabels,
            datasets: [{
                label: 'RPE',
                data: rpeValues,
                borderColor: '#4f46e5',
                backgroundColor: '#c7d2fe',
                tension: 0.3,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 5,
                    ticks: {
                        stepSize: 1,
                        color: textColor
                    },
                    grid: {
                        color: gridColor
                    }
                },
                x: {
                    ticks: {
                        color: textColor
                    },
                    grid: {
                        color: gridColor
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
    
    renderChart('chartMov', {
        type: 'bar',
        data: {
            labels: sortedMoves.map(m => m[0]),
            datasets: [{
                label: 'Frecuencia',
                data: sortedMoves.map(m => m[1]),
                backgroundColor: '#4f46e5'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: textColor
                    },
                    grid: {
                        color: gridColor
                    }
                },
                x: {
                    ticks: {
                        color: textColor
                    },
                    grid: {
                        color: gridColor
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
    
    renderChart('chartWeek', {
        type: 'bar',
        data: {
            labels: sortedWeeks.map(w => w[0]),
            datasets: [{
                label: 'Volumen (kg)',
                data: sortedWeeks.map(w => w[1]),
                backgroundColor: '#10b981'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        color: textColor
                    },
                    grid: {
                        color: gridColor
                    }
                },
                x: {
                    ticks: {
                        color: textColor
                    },
                    grid: {
                        color: gridColor
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
}

// Extensión de Date para obtener número de semana
Date.prototype.getWeek = function() {
    const date = new Date(this.getTime());
    date.setHours(0, 0, 0, 0);
    date.setDate(date.getDate() + 3 - (date.getDay() + 6) % 7);
    const week1 = new Date(date.getFullYear(), 0, 4);
    return 1 + Math.round(((date.getTime() - week1.getTime()) / 86400000 - 3 + (week1.getDay() + 6) % 7) / 7);
};

// --- FUNCIONES DE ESTADÍSTICAS ---
function renderStats() {
    const fromDate = document.getElementById('statsFrom').value;
    const toDate = document.getElementById('statsTo').value;
    
    let filteredEntries = [...entries];
    if (fromDate) {
        filteredEntries = filteredEntries.filter(e => e.cond.date >= fromDate);
    }
    if (toDate) {
        filteredEntries = filteredEntries.filter(e => e.cond.date <= toDate);
    }
    
    // Estadísticas básicas
    document.getElementById('statTotal').textContent = filteredEntries.length;
    
    const rpeEntries = filteredEntries.filter(e => e.cond.rpe);
    const avgRPE = rpeEntries.reduce((sum, e) => sum + parseInt(e.cond.rpe), 0) / rpeEntries.length || 0;
    document.getElementById('statAvgRPE').textContent = avgRPE.toFixed(1);
    
    let totalVol = 0;
    const uniqueMoves = new Set();
    filteredEntries.forEach(e => {
        e.wl.forEach(w => {
            uniqueMoves.add(w.move);
            w.roundsData.forEach(r => {
                const avgWeight = r.weights.reduce((a, b) => a + b, 0) / r.weights.length;
                totalVol += r.reps * avgWeight;
            });
        });
    });
    
    document.getElementById('statTotalVol').textContent = Math.round(totalVol);
    document.getElementById('statUniqueWL').textContent = uniqueMoves.size;
    
    // Actualizar lista de movimientos únicos
    const movesContainer = document.getElementById('uniqueMovesList');
    movesContainer.innerHTML = '';
    Array.from(uniqueMoves).sort().forEach(move => {
        const tag = document.createElement('span');
        tag.className = 'unique-move-tag';
        tag.textContent = move;
        movesContainer.appendChild(tag);
    });
    
    // Configurar botón para mostrar/ocultar movimientos
    document.getElementById('toggleMovesBtn').onclick = () => {
        movesContainer.classList.toggle('hidden');
        const btn = document.getElementById('toggleMovesBtn');
        btn.textContent = movesContainer.classList.contains('hidden') ? 'Mostrar lista' : 'Ocultar lista';
    };
    
    // Top 3 movimientos por volumen
    const moveVol = {};
    filteredEntries.forEach(e => {
        e.wl.forEach(w => {
            let vol = 0;
            w.roundsData.forEach(r => {
                const avgWeight = r.weights.reduce((a, b) => a + b, 0) / r.weights.length;
                vol += r.reps * avgWeight;
            });
            moveVol[w.move] = (moveVol[w.move] || 0) + vol;
        });
    });
    const topMoves = Object.entries(moveVol).sort((a, b) => b[1] - a[1]).slice(0, 3);
    
    // Configuración del tema para gráficos
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#e5e7eb' : '#374151';
    
    renderChart('chartStatTopMov', {
        type: 'doughnut',
        data: {
            labels: topMoves.map(m => m[0]),
            datasets: [{
                data: topMoves.map(m => m[1]),
                backgroundColor: ['#4f46e5', '#6366f1', '#818cf8']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
    
    // Distribución WOD vs Fuerza
    let wodCount = 0;
    let wlCount = 0;
    filteredEntries.forEach(e => {
        if (e.cond.wodText) wodCount++;
        if (e.wl.length) wlCount++;
    });
    
    renderChart('chartStatType', {
        type: 'pie',
        data: {
            labels: ['WODs', 'Fuerza'],
            datasets: [{
                data: [wodCount, wlCount],
                backgroundColor: ['#4f46e5', '#10b981']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
}

// Exportar estadísticas a CSV
document.getElementById('exportStats').onclick = () => {
    const fromDate = document.getElementById('statsFrom').value;
    const toDate = document.getElementById('statsTo').value;
    
    let filteredEntries = [...entries];
    if (fromDate) {
        filteredEntries = filteredEntries.filter(e => e.cond.date >= fromDate);
    }
    if (toDate) {
        filteredEntries = filteredEntries.filter(e => e.cond.date <= toDate);
    }
    
    // Preparar datos para exportar
    const data = filteredEntries.map(entry => {
        return {
            fecha: entry.cond.date,
            tipo: entry.cond.type || '',
            wod: entry.cond.wodText || '',
            resultado: entry.cond.result || '',
            rpe: entry.cond.rpe || '',
            movimientos: entry.wl.map(w => w.move).join(', '),
            volumen_total: entry.wl.reduce((total, w) => {
                return total + w.roundsData.reduce((sum, r) => {
                    const avgWeight = r.weights.reduce((a, b) => a + b, 0) / r.weights.length;
                    return sum + (r.reps * avgWeight);
                }, 0);
            }, 0)
        };
    });
    
    // Convertir a CSV
    const headers = ['Fecha', 'Tipo', 'WOD', 'Resultado', 'RPE', 'Movimientos', 'Volumen Total (kg)'];
    const csvRows = [
        headers.join(','),
        ...data.map(row => [
            row.fecha,
            `"${row.tipo}"`,
            `"${row.wod.replace(/"/g, '""')}"`,
            `"${row.resultado}"`,
            row.rpe,
            `"${row.movimientos}"`,
            Math.round(row.volumen_total)
        ].join(','))
    ];
    
    const csvContent = csvRows.join('\n');
    
    // Descargar archivo
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `estadisticas_${fromDate || 'inicio'}_${toDate || 'fin'}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

document.getElementById('applyStats').onclick = renderStats;

// --- FUNCIONES DE RM ---
function calculate1RM(weight, reps) {
    // Fórmula de Epley para estimar 1RM
    return weight * (1 + reps / 30);
}

function calculatePercentageRM(rm, percentage) {
    return rm * (percentage / 100);
}

function renderRM() {
    const rmContainer = document.getElementById('rmContainer');
    rmContainer.innerHTML = '';
    
    // Calcular RM por movimiento
    const rmData = {};
    entries.forEach(e => {
        e.wl.forEach(w => {
            if (!rmData[w.move]) rmData[w.move] = [];
            w.roundsData.forEach(r => {
                const maxWeight = Math.max(...r.weights);
                rmData[w.move].push({
                    date: e.cond.date,
                    weight: maxWeight,
                    reps: r.reps,
                    rm: calculate1RM(maxWeight, r.reps)
                });
            });
        });
    });
    
    // Calcular mejor RM por movimiento
    const bestRM = {};
    Object.entries(rmData).forEach(([move, records]) => {
        bestRM[move] = {
            maxWeight: Math.max(...records.map(r => r.weight)),
            maxRM: Math.max(...records.map(r => r.rm)),
            records: records.sort((a, b) => new Date(a.date) - new Date(b.date))
        };
    });
    
    // Configuración del tema para gráficos
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#e5e7eb' : '#374151';
    const gridColor = isDark ? 'rgba(229, 231, 235, 0.1)' : 'rgba(55, 65, 81, 0.1)';
    
    // Renderizar gráficos por movimiento
    Object.entries(bestRM).forEach(([move, data]) => {
        if (data.records.length < 2) return; // Solo mostrar movimientos con al menos 2 registros
        
        const card = document.createElement('div');
        card.className = 'bg-white dark:bg-gray-700 p-4 rounded-lg shadow border dark:border-gray-600';
        
        // Calcular porcentajes de RM
        const rm85 = calculatePercentageRM(data.maxRM, 85);
        const rm90 = calculatePercentageRM(data.maxRM, 90);
        const rm95 = calculatePercentageRM(data.maxRM, 95);
        
        card.innerHTML = `
            <h3 class="font-bold text-lg dark:text-white">${move}</h3>
            <div class="flex justify-between items-center mb-2">
                <p class="text-sm text-gray-600 dark:text-gray-400">RM Real: <strong class="text-indigo-700 dark:text-indigo-400">${Math.round(data.maxWeight)} kg</strong></p>
                <p class="text-sm text-gray-600 dark:text-gray-400">RM Estimado: <strong class="text-indigo-700 dark:text-indigo-400">${Math.round(data.maxRM)} kg</strong></p>
            </div>
            <div class="rm-chart-container">
                <canvas id="rm-chart-${move.replace(/\s+/g, '-')}"></canvas>
            </div>
            <table class="rm-table">
                <thead>
                    <tr>
                        <th>% RM</th>
                        <th>Peso (kg)</th>
                        <th>Reps estimadas</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>85%</td>
                        <td>${Math.round(rm85)}</td>
                        <td>5-8</td>
                    </tr>
                    <tr>
                        <td>90%</td>
                        <td>${Math.round(rm90)}</td>
                        <td>3-5</td>
                    </tr>
                    <tr>
                        <td>95%</td>
                        <td>${Math.round(rm95)}</td>
                        <td>1-3</td>
                    </tr>
                </tbody>
            </table>
        `;
        rmContainer.appendChild(card);
        
        renderChart(`rm-chart-${move.replace(/\s+/g, '-')}`, {
            type: 'line',
            data: {
                labels: data.records.map(r => formatDate(r.date)),
                datasets: [
                    {
                        label: 'Peso Máximo (kg)',
                        data: data.records.map(r => r.weight),
                        borderColor: '#10b981',
                        backgroundColor: 'rgba(16, 185, 129, 0.1)',
                        tension: 0.3,
                        fill: false
                    },
                    {
                        label: 'RM Estimado (kg)',
                        data: data.records.map(r => r.rm),
                        borderColor: '#4f46e5',
                        backgroundColor: 'rgba(79, 70, 229, 0.1)',
                        tension: 0.3,
                        fill: false
                    }
                ]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                scales: {
                    y: {
                        beginAtZero: false,
                        ticks: {
                            color: textColor
                        },
                        grid: {
                            color: gridColor
                        }
                    },
                    x: {
                        ticks: {
                            color: textColor
                        },
                        grid: {
                            color: gridColor
                        }
                    }
                },
                plugins: {
                    legend: {
                        position: 'bottom',
                        labels: {
                            color: textColor,
                            boxWidth: 12
                        }
                    }
                }
            }
        });
    });
    
    if (rmContainer.children.length === 0) {
        rmContainer.innerHTML = '<div class="col-span-2 text-center py-8 text-gray-500 dark:text-gray-400">No hay suficientes datos para calcular RM</div>';
    }
}

// Exportar datos RM a CSV
document.getElementById('exportRM').onclick = () => {
    // Calcular RM por movimiento
    const rmData = {};
    entries.forEach(e => {
        e.wl.forEach(w => {
            if (!rmData[w.move]) rmData[w.move] = [];
            w.roundsData.forEach(r => {
                const maxWeight = Math.max(...r.weights);
                rmData[w.move].push({
                    date: e.cond.date,
                    weight: maxWeight,
                    reps: r.reps,
                    rm: calculate1RM(maxWeight, r.reps)
                });
            });
        });
    });
    
    // Preparar datos para exportar
    const data = [];
    Object.entries(rmData).forEach(([move, records]) => {
        const bestRecord = records.reduce((best, current) => {
            return (current.weight > best.weight) ? current : best;
        }, {weight: 0});
        
        data.push({
            movimiento: move,
            rm_real: bestRecord.weight,
            rm_estimado: calculate1RM(bestRecord.weight, bestRecord.reps),
            fecha: bestRecord.date,
            reps: bestRecord.reps,
            rm_85: calculatePercentageRM(calculate1RM(bestRecord.weight, bestRecord.reps), 85),
            rm_90: calculatePercentageRM(calculate1RM(bestRecord.weight, bestRecord.reps), 90),
            rm_95: calculatePercentageRM(calculate1RM(bestRecord.weight, bestRecord.reps), 95)
        });
    });
    
    // Convertir a CSV
    const headers = ['Movimiento', 'RM Real (kg)', 'RM Estimado (kg)', 'Fecha', 'Reps', '85% RM', '90% RM', '95% RM'];
    const csvRows = [
        headers.join(','),
        ...data.map(row => [
            row.movimiento,
            Math.round(row.rm_real),
            Math.round(row.rm_estimado),
            row.fecha,
            row.reps,
            Math.round(row.rm_85),
            Math.round(row.rm_90),
            Math.round(row.rm_95)
        ].join(','))
    ];
    
    const csvContent = csvRows.join('\n');
    
    // Descargar archivo
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `rm_data_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
};

// --- FUNCIONES DE ANÁLISIS WOD ---
function renderWODAnalysis() {
    // Configurar fechas por defecto (últimos 3 meses)
    const defaultTo = new Date();
    const defaultFrom = new Date();
    defaultFrom.setMonth(defaultFrom.getMonth() - 3);
    
    document.getElementById('wodFrom').value = defaultFrom.toISOString().split('T')[0];
    document.getElementById('wodTo').value = defaultTo.toISOString().split('T')[0];
    
    // Cargar movimientos comunes
    renderMovementTags();
    
    // Configurar búsqueda
    document.getElementById('movementSearch').oninput = (e) => {
        const term = e.target.value.toLowerCase();
        document.querySelectorAll('.movement-tag').forEach(tag => {
            if (tag.textContent.toLowerCase().includes(term)) {
                tag.style.display = 'inline-block';
            } else {
                tag.style.display = 'none';
            }
        });
    };
    
    // Configurar pestañas de combinaciones
    document.getElementById('tabPairs').onclick = (e) => {
        e.preventDefault();
        document.getElementById('tabPairs').classList.add('active');
        document.getElementById('tabTriples').classList.remove('active');
        renderCombinations(2);
    };
    
    document.getElementById('tabTriples').onclick = (e) => {
        e.preventDefault();
        document.getElementById('tabTriples').classList.add('active');
        document.getElementById('tabPairs').classList.remove('active');
        renderCombinations(3);
    };
    
    // Configurar paginación
    document.getElementById('prevPage').onclick = () => {
        if (currentPage > 1) {
            currentPage--;
            renderWODExamples();
        }
    };
    
    document.getElementById('nextPage').onclick = () => {
        const totalPages = Math.ceil(filteredWODs.length / itemsPerPage);
        if (currentPage < totalPages) {
            currentPage++;
            renderWODExamples();
        }
    };
    
    // Aplicar filtros
    document.getElementById('applyWODFilter').onclick = applyWODFilters;
    
    // Exportar datos
    document.getElementById('exportData').onclick = exportWODData;
    
    // Aplicar filtros iniciales
    applyWODFilters();
}

let filteredWODs = [];

function applyWODFilters() {
    const fromDate = document.getElementById('wodFrom').value;
    const toDate = document.getElementById('wodTo').value;
    
    // Mostrar spinner de carga
    const spinner = document.getElementById('filterSpinner');
    const filterText = document.getElementById('filterText');
    spinner.classList.remove('hidden');
    filterText.textContent = 'Procesando...';
    
    // Usar setTimeout para permitir que la UI se actualice
    setTimeout(() => {
        filteredWODs = entries.filter(e => e.cond.wodText).sort((a, b) => new Date(b.cond.date) - new Date(a.cond.date));
        
        if (fromDate) {
            filteredWODs = filteredWODs.filter(e => e.cond.date >= fromDate);
        }
        if (toDate) {
            filteredWODs = filteredWODs.filter(e => e.cond.date <= toDate);
        }
        
        // Actualizar estadísticas
        updateWODStats();
        
        // Renderizar gráficos
        renderWODCharts();
        
        // Renderizar combinaciones (pares por defecto)
        renderCombinations(2);
        
        // Renderizar ejemplos de WODs
        currentPage = 1;
        renderWODExamples();
        
        // Ocultar spinner
        spinner.classList.add('hidden');
        filterText.textContent = 'Aplicar';
    }, 100);
}

function updateWODStats() {
    // Extraer todos los movimientos de los WODs filtrados
    const allMovements = [];
    filteredWODs.forEach(wod => {
        const movements = extractMovementsFromWOD(wod.cond.wodText);
        allMovements.push(...movements);
    });
    
    // Estadísticas generales
    document.getElementById('statWODs').textContent = filteredWODs.length;
    
    const uniqueMovements = [...new Set(allMovements.map(m => m.name))];
    document.getElementById('statMovements').textContent = uniqueMovements.length;
    
    const uniqueCategories = [...new Set(allMovements.map(m => m.category))];
    document.getElementById('statCategories').textContent = uniqueCategories.length;
    
    document.getElementById('statFrequency').textContent = allMovements.length;
    
    // Actualizar información del filtro
    const fromDate = document.getElementById('wodFrom').value;
    const toDate = document.getElementById('wodTo').value;
    document.getElementById('wodFilterInfo').textContent = 
        `Mostrando ${filteredWODs.length} WODs desde ${formatDate(fromDate)} hasta ${formatDate(toDate)}`;
}

function extractMovementsFromWOD(wodText) {
    if (!wodText) return [];
    
    // Buscar movimientos conocidos en el texto del WOD
    const foundMovements = [];
    WOD_MOVEMENTS.forEach(mov => {
        const regex = new RegExp(`\\b${mov.name}\\b`, 'gi');
        if (wodText.match(regex)) {
            foundMovements.push({
                name: mov.name,
                category: mov.category
            });
        }
    });
    
    return foundMovements;
}

function renderMovementTags() {
    const container = document.getElementById('commonMovements');
    container.innerHTML = '';
    
    // Contar frecuencia de movimientos
    const movementCounts = {};
    entries.forEach(e => {
        if (e.cond.wodText) {
            const movements = extractMovementsFromWOD(e.cond.wodText);
            movements.forEach(m => {
                movementCounts[m.name] = (movementCounts[m.name] || 0) + 1;
            });
        }
    });
    
    // Ordenar por frecuencia
    const sortedMovements = Object.entries(movementCounts)
        .sort((a, b) => b[1] - a[1])
        .map(([name]) => {
            const mov = WOD_MOVEMENTS.find(m => m.name === name);
            return { name, category: mov ? mov.category : 'Other' };
        });
    
    // Crear tags
    sortedMovements.forEach(mov => {
        const tag = document.createElement('span');
        tag.className = 'movement-tag';
        tag.textContent = mov.name;
        tag.title = `${mov.category} - ${movementCounts[mov.name]} apariciones`;
        tag.onclick = () => filterByMovement(mov.name);
        container.appendChild(tag);
    });
}

function filterByMovement(movement) {
    currentFilterMovement = movement;
    filteredWODs = entries.filter(e => {
        if (!e.cond.wodText) return false;
        const movements = extractMovementsFromWOD(e.cond.wodText);
        return movements.some(m => m.name === movement);
    }).sort((a, b) => new Date(b.cond.date) - new Date(a.cond.date));
    
    updateWODStats();
    renderWODCharts();
    renderCombinations(2);
    currentPage = 1;
    renderWODExamples();
    
    // Resaltar el movimiento seleccionado
    document.querySelectorAll('.movement-tag').forEach(tag => {
        if (tag.textContent === movement) {
            tag.style.backgroundColor = '#4f46e5';
            tag.style.color = 'white';
        } else {
            tag.style.backgroundColor = '#e0e7ff';
            tag.style.color = '#4f46e5';
        }
    });
}

function renderWODCharts() {
    // Extraer todos los movimientos
    const allMovements = [];
    filteredWODs.forEach(wod => {
        const movements = extractMovementsFromWOD(wod.cond.wodText);
        allMovements.push(...movements);
    });
    
    // Top 5 movimientos
    const moveCounts = {};
    allMovements.forEach(m => {
        moveCounts[m.name] = (moveCounts[m.name] || 0) + 1;
    });
    const topMoves = Object.entries(moveCounts).sort((a, b) => b[1] - a[1]).slice(0, 5);
    
    // Configuración del tema para gráficos
    const isDark = document.documentElement.classList.contains('dark');
    const textColor = isDark ? '#e5e7eb' : '#374151';
    
    renderChart('chartTopWODMov', {
        type: 'bar',
        data: {
            labels: topMoves.map(m => m[0]),
            datasets: [{
                label: 'Frecuencia',
                data: topMoves.map(m => m[1]),
                backgroundColor: '#4f46e5'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        stepSize: 1,
                        color: textColor
                    }
                },
                x: {
                    ticks: {
                        color: textColor
                    }
                }
            },
            plugins: {
                legend: {
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
    
    // Distribución por categorías
    const catCounts = {};
    allMovements.forEach(m => {
        catCounts[m.category] = (catCounts[m.category] || 0) + 1;
    });
    
    renderChart('chartCategoryDist', {
        type: 'doughnut',
        data: {
            labels: Object.keys(catCounts),
            datasets: [{
                data: Object.values(catCounts),
                backgroundColor: ['#4f46e5', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6']
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        color: textColor
                    }
                }
            }
        }
    });
}

function renderCombinations(size) {
    const container = document.getElementById('combinationsContainer');
    container.innerHTML = '';
    
    // Extraer todas las combinaciones de movimientos
    const combinations = {};
    filteredWODs.forEach(wod => {
        const movements = extractMovementsFromWOD(wod.cond.wodText).map(m => m.name);
        
        // Generar todas las combinaciones posibles del tamaño especificado
        for (let i = 0; i <= movements.length - size; i++) {
            const combo = movements.slice(i, i + size).sort().join(' + ');
            combinations[combo] = (combinations[combo] || 0) + 1;
        }
    });
    
    // Ordenar por frecuencia y tomar las top 6
    const topCombos = Object.entries(combinations)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 6);
    
    if (topCombos.length === 0) {
        container.innerHTML = '<div class="col-span-2 text-center py-4 text-gray-500 dark:text-gray-400">No se encontraron combinaciones</div>';
        return;
    }
    
    topCombos.forEach(([combo, count]) => {
        const div = document.createElement('div');
        div.className = 'bg-white dark:bg-gray-700 p-3 rounded border dark:border-gray-600 shadow-sm';
        div.innerHTML = `
            <div class="flex justify-between items-center">
                <span class="font-medium dark:text-white">${combo}</span>
                <span class="bg-indigo-100 dark:bg-indigo-900 text-indigo-800 dark:text-indigo-300 text-xs px-2 py-1 rounded-full">${count} veces</span>
            </div>
        `;
        container.appendChild(div);
    });
}

function renderWODExamples() {
    const container = document.getElementById('wodExamples');
    container.innerHTML = '';
    
    const startIdx = (currentPage - 1) * itemsPerPage;
    const endIdx = startIdx + itemsPerPage;
    const paginatedWODs = filteredWODs.slice(startIdx, endIdx);
    
    if (paginatedWODs.length === 0) {
        container.innerHTML = '<div class="text-center py-8 text-gray-500 dark:text-gray-400">No hay WODs que coincidan con los filtros</div>';
        document.getElementById('wodPagination').classList.add('hidden');
        return;
    }
    
    document.getElementById('wodPagination').classList.remove('hidden');
    
    paginatedWODs.forEach(wod => {
        const movements = extractMovementsFromWOD(wod.cond.wodText);
        
        const div = document.createElement('div');
        div.className = 'wod-example bg-gray-50 dark:bg-gray-700 p-4 rounded-lg';
        div.innerHTML = `
            <div class="flex justify-between items-start">
                <div>
                    <strong class="text-indigo-700 dark:text-indigo-400">${formatDate(wod.cond.date)}</strong>
                    <p class="text-sm text-gray-600 dark:text-gray-400">${wod.cond.type || 'N/A'}</p>
                </div>
                ${wod.cond.result ? `<span class="bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-300 text-xs px-2 py-1 rounded-full">${wod.cond.result}</span>` : ''}
            </div>
            <div class="mt-2">
                <p class="whitespace-pre-line font-medium dark:text-white">${wod.cond.wodText}</p>
            </div>
            ${movements.length > 0 ? `
            <div class="mt-3 flex flex-wrap gap-1">
                ${movements.map(m => `
                    <span class="category-badge" style="background-color: ${getCategoryColor(m.category)}20; color: ${getCategoryColor(m.category)};">
                        ${m.name} <span class="text-xs opacity-70">(${m.category})</span>
                    </span>
                `).join('')}
            </div>
            ` : ''}
        `;
        container.appendChild(div);
    });
    
    // Actualizar controles de paginación
    const totalPages = Math.ceil(filteredWODs.length / itemsPerPage);
    document.getElementById('pageInfo').textContent = `${currentPage}/${totalPages}`;
    document.getElementById('prevPage').disabled = currentPage <= 1;
    document.getElementById('nextPage').disabled = currentPage >= totalPages;
}

function getCategoryColor(category) {
    const colors = {
        'Gymnastics': '#4f46e5',
        'Weightlifting': '#10b981',
        'Cardio': '#f59e0b',
        'Bodyweight': '#ef4444'
    };
    return colors[category] || '#8b5cf6';
}

function exportWODData() {
    // Preparar datos para exportar
    const data = filteredWODs.map(wod => {
        const movements = extractMovementsFromWOD(wod.cond.wodText);
        return {
            date: wod.cond.date,
            type: wod.cond.type,
            wod: wod.cond.wodText,
            result: wod.cond.result,
            movements: movements.map(m => m.name),
            categories: [...new Set(movements.map(m => m.category))]
        };
    });
    
    // Convertir a CSV
    const headers = ['Fecha', 'Tipo', 'WOD', 'Resultado', 'Movimientos', 'Categorías'];
    const csvRows = [
        headers.join(','),
        ...data.map(row => [
            row.date,
            `"${row.type || ''}"`,
            `"${row.wod.replace(/"/g, '""')}"`,
            `"${row.result || ''}"`,
            `"${row.movements.join(', ')}"`,
            `"${row.categories.join(', ')}"`
        ].join(','))
    ];
    
    const csvContent = csvRows.join('\n');
    
    // Descargar archivo
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `wod_analysis_${new Date().toISOString().split('T')[0]}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
}

// --- FUNCIONES AUXILIARES ---
function renderChart(id, config) {
    // Destruir gráfico existente si lo hay
    if (chartInstances[id]) {
        chartInstances[id].destroy();
    }
    
    const ctx = document.getElementById(id).getContext('2d');
    chartInstances[id] = new Chart(ctx, config);
}

// --- INICIALIZACIÓN ---
document.addEventListener('DOMContentLoaded', () => {
    loadCondTypes();
    document.getElementById('condDate').valueAsDate = new Date();
    
    // Cargar datos de ejemplo si no hay nada
    if (entries.length === 0) {
        const exampleDate = new Date();
        exampleDate.setDate(exampleDate.getDate() - 7);
        
        entries = [
            {
                id: Date.now() - 2,
                cond: {
                    date: exampleDate.toISOString().split('T')[0],
                    type: "AMRAP",
                    wodText: "20 min AMRAP:\n5 Pull-ups\n10 Push-ups\n15 Air Squats",
                    result: "8 rounds + 5 Pull-ups",
                    rpe: "3"
                },
                wl: []
            },
            {
                id: Date.now() - 1,
                cond: {
                    date: new Date().toISOString().split('T')[0],
                    type: "For Time",
                    wodText: "21-15-9\nDeadlift 100kg\nHandstand Push-ups",
                    result: "9:45",
                    rpe: "4"
                },
                wl: [
                    {
                        move: "Deadlift",
                        roundsData: [
                            { reps: 5, weights: [80, 85, 90] },
                            { reps: 3, weights: [90, 95, 100] }
                        ]
                    }
                ]
            }
        ];
        localStorage.setItem('rtCrossData_vFinal', JSON.stringify(entries));
    }
    
    // Mostrar pestaña de registro por defecto
    document.getElementById('tabInput').click();
});